<?php
    require 'connect.php';

    // jika interaksi dengam nama aksi maka akan melakukan proses inisialisasi
    if(isset($_POST['aksi'])){
        //jika interaksi tambah data
        if($_POST['aksi'] == "tambah"){

            //inisalisasi form konfigurasi
            $nama_tamu = $_POST['nama_tamu'];
            $email = $_POST['email'];
            date_default_timezone_set("Asia/Jakarta");
            $waktu = date('Y-m-d H:i:s');
            $keterangan = $_POST['keterangan'];

            // proses query
            $query = "INSERT INTO bukutamu VALUES(null, '$nama_tamu', '$email', '$waktu', '$keterangan')";
            // connect query to sql
            $sql = mysqLi_query($koneksi, $query);

            if($sql){
                header("location:index.php");
            } else {
                echo $query;
            }
        
        //Jika interaksi edit data
        }else if ($_POST['aksi'] == "edit"){

            $nomor = $_POST['nomor'];
            $nama = $_POST['nama_tamu'];
            $email = $_POST['email'];
            date_default_timezone_set("Asia/Jakarta");
            $waktu = date('Y-m-d H:i:s');
            $komentar = $_POST['keterangan'];

            $query = "UPDATE bukutamu SET nama='$nama', email='$email', komentar='$komentar', waktu='$waktu' WHERE nomor='$nomor';";
            $sql = mysqLi_query($koneksi, $query);
            header("location:index.php");
        }
    }

    // jika interaksi metode GET maka akan menghapus
    if(isset($_GET['hapus'])){
        $nomor = $_GET['hapus'];
        $query = "DELETE FROM bukutamu WHERE nomor = '$nomor';";
        $sql = mysqLi_query($koneksi, $query);

        if($sql){
            header("location:index.php");
        } else {
            echo $query;
        }
    }

    
    
?><?php /**PATH E:\SEMESTER 4\PEMWEB\Laravel\PPW10_M0520046\resources\views/proses.blade.php ENDPATH**/ ?>