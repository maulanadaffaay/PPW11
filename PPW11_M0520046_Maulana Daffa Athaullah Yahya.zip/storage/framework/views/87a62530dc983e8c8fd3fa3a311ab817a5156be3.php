<!-- Connect to MySQL -->
<?php
    // inisialisasi
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'database_buku_tamu';
    
    $koneksi = mysqLi_connect($host, $user, $password, $database);
    if($koneksi){
        // echo "Amangg";
    }

    // Tahap 1: Koneksikan ke DB
    mysqLi_select_db($koneksi, $database);
    
?>
<?php /**PATH E:\SEMESTER 4\PEMWEB\Laravel\PPW10_M0520046\resources\views/connect.blade.php ENDPATH**/ ?>